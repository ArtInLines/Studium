
/*
SET CURRENT SCHEMA Uni;
DROP TABLE prüfen;
DROP TABLE voraussetzen;
DROP TABLE hören;
DROP TABLE vorlesungen;
DROP TABLE STUDENTEN;
DROP TABLE Assistenten ;
DROP TABLE PROFESSOREN ;
DROP SCHEMA Uni RESTRICT;
*/

CREATE SCHEMA Uni;
SET CURRENT SCHEMA Uni;

CREATE TABLE Professoren (
    PersNr integer     NOT NULL PRIMARY KEY,
    Name   varchar(50) NOT NULL,
    Rang   char(2)     CONSTRAINT professoren_rang_ck CHECK (rang IN ('C2', 'C3', 'C4')),
    Raum   integer     CONSTRAINT professoren_raum_uq UNIQUE 
);

CREATE TABLE Assistenten (
    PersNr     integer     NOT NULL PRIMARY KEY,
    Name       varchar(50) NOT NULL,
    Fachgebiet varchar(50),
    Boss       integer     REFERENCES Professoren ON DELETE SET NULL
);

CREATE TABLE Studenten (
  MatrNr   integer     NOT NULL PRIMARY KEY,
  Name     varchar(50) NOT NULL,
  Semester integer     CONSTRAINT studenten_semester_ck CHECK (semester BETWEEN 1 AND 25)
);


CREATE TABLE Vorlesungen (
  VorlNr      integer     NOT NULL PRIMARY KEY,
  Titel       varchar(50) NOT NULL,
  SWS         integer     CONSTRAINT vorlesungen_sws_ck check(sws BETWEEN 1 AND 4),
  gelesen_von integer     REFERENCES Professoren ON DELETE SET null
);

CREATE TABLE hören (
  MatrNr integer REFERENCES Studenten ON DELETE CASCADE,
  VorlNr integer REFERENCES Vorlesungen ON DELETE CASCADE,
  
  PRIMARY key(MatrNr, VorlNr)
);

CREATE TABLE voraussetzen (
  vorgänger  integer NOT NULL REFERENCES vorlesungen  ON DELETE CASCADE,
  nachfolger integer NOT NULL REFERENCES vorlesungen ON DELETE CASCADE,
  
  PRIMARY key(vorgänger, nachfolger)
);

CREATE TABLE prüfen (
  MatrNr integer NOT NULL REFERENCES Studenten    ON DELETE CASCADE,
  VorlNr integer NOT NULL REFERENCES Vorlesungen  ON DELETE RESTRICT,
  Prüfer integer          REFERENCES Professoren  ON DELETE SET null,
  Note   decimal(2, 1)    CONSTRAINT prüfen_ck_note CHECK (note BETWEEN 0.7 AND 5.0),
  
  PRIMARY KEY (MatrNr, VorlNr)
);
